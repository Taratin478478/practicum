import catboost
assert(catboost.__version__ == '1.2.7')